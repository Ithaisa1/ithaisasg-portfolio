(function () {
  'use strict';
  var btn = document.getElementById('completar'), end = document.getElementById('fin'), msg = document.getElementById('estado');
  function done() { GCMScorm.complete(); if (msg) msg.textContent = '✔ ' + window.GCM_LABELS.completed; if (btn) btn.disabled = true; }
  if (btn) btn.addEventListener('click', done);
  if (end && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (es) { if (es[0].isIntersecting) done(); }).observe(end);
  }
})();
