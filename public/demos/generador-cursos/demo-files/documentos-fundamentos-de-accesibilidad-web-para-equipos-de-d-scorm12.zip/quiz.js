(function () {
  'use strict';
  var data = window.GCM_QUIZ, L = window.GCM_LABELS, root = document.getElementById('quiz');
  if (!data || !root) return;
  function el(tag, attrs, text) {
    var n = document.createElement(tag), k;
    for (k in (attrs || {})) n.setAttribute(k, attrs[k]);
    if (text != null) n.textContent = text;
    return n;
  }
  function shuffled(n) { var a = [], i, j, t; for (i = 0; i < n; i++) a.push(i); for (i = n - 1; i > 0; i--) { j = Math.floor(Math.random() * (i + 1)); t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  var getters = [];
  var list = el('ol', { 'class': 'preguntas' });
  data.questions.forEach(function (q, qi) {
    var li = el('li', { 'class': 'pregunta' });
    li.appendChild(el('p', {}, L.question + ' ' + (qi + 1) + ' · ' + q.pointsLabel));
    var stem = el('div'); stem.innerHTML = q.stemHtml; li.appendChild(stem);   // HTML ya limpiado al exportar
    var name = 'q' + qi, get;
    if (q.qtype === 'multichoice' || q.qtype === 'truefalse') {
      var multi = q.qtype === 'multichoice' && !q.singleAnswer, inputs = [];
      shuffled(q.answers.length).forEach(function (ai) {
        var lab = el('label', { 'class': 'opcion' }), inp = el('input', { type: multi ? 'checkbox' : 'radio', name: name, value: ai });
        inputs.push(inp); lab.appendChild(inp); lab.appendChild(document.createTextNode(' ' + (q.qtype === 'truefalse' ? (ai === 0 ? L.trueText : L.falseText) : q.answers[ai].text)));
        li.appendChild(lab); li.appendChild(document.createElement('br'));
      });
      get = function () {
        var sel = inputs.filter(function (i) { return i.checked; }).map(function (i) { return Number(i.value); });
        return multi ? sel : (sel.length ? sel[0] : null);
      };
    } else if (q.qtype === 'shortanswer') {
      var t = el('input', { type: 'text', autocomplete: 'off' }); li.appendChild(t); get = function () { return t.value; };
    } else if (q.qtype === 'essay') {
      var ta = el('textarea', { rows: 6, 'class': 'ancho' }); li.appendChild(ta); li.appendChild(el('p', { 'class': 'nota' }, L.notGraded)); get = function () { return ta.value; };
    } else {
      var sels = [], opts = q.answers.map(function (a) { return a.matchText; }).sort(); get = function () { return sels.map(function (s) { return s.value; }); };
      q.answers.forEach(function (a) {
        var row = el('div'), s = el('select');
        row.appendChild(document.createTextNode(a.text + ' → ')); s.appendChild(el('option', { value: '' }, '—'));
        opts.forEach(function (o) { s.appendChild(el('option', { value: o }, o)); });
        sels.push(s); row.appendChild(s); li.appendChild(row);
      });
    }
    li.appendChild(el('div', { 'class': 'resultado', 'aria-live': 'polite' }));
    getters.push(get); list.appendChild(li);
  });
  root.appendChild(list);
  var btn = el('button', { type: 'button' }, L.submit), out = el('p', { 'class': 'aviso', 'aria-live': 'polite' });
  btn.addEventListener('click', function () {
    var responses = getters.map(function (g) { return g(); }), r = GCMScoring.scoreQuiz(data, responses);
    var results = list.querySelectorAll('.resultado');
    data.questions.forEach(function (q, i) {
      var s = r.perQuestion[i], box = results[i];
      box.textContent = s === null ? '' : (s >= q.points ? '✔ ' + L.correct : (s > 0 ? '◐ ' + L.partial : '✘ ' + L.incorrect));
      if (q.explanationHtml) { var d = el('div'); d.innerHTML = q.explanationHtml; box.appendChild(d); }
    });
    out.textContent = L.score + ': ' + r.raw + ' / ' + r.max + ' (' + Math.round(r.percent) + ' %) — ' + (r.passed ? L.passed : L.failed);
    GCMScorm.score(r.percent, 100, r.passed);
  });
  root.appendChild(btn); root.appendChild(out);
})();
