(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.GCMScoring = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  function norm(s) { return String(s).replace(/\s+/g, ' ').trim().toLowerCase(); }
  function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
  /** Puntos obtenidos (0..points) por una respuesta. Una pregunta abierta (essay) no se corrige: devuelve null. */
  function scoreQuestion(q, response) {
    var pts = q.points;
    switch (q.qtype) {
      case 'essay': return null;
      case 'truefalse':
        return typeof response === 'number' && q.answers[response] ? (q.answers[response].fraction > 0 ? pts : 0) : 0;
      case 'multichoice': {
        var sel = Object.prototype.toString.call(response) === '[object Array]' ? response : (typeof response === 'number' ? [response] : []);
        var sum = 0, i;
        for (i = 0; i < sel.length; i++) if (q.answers[sel[i]]) sum += q.answers[sel[i]].fraction;
        return clamp(sum / 100, 0, 1) * pts;
      }
      case 'shortanswer': {
        var given = norm(response == null ? '' : response), best = 0, j;
        if (!given) return 0;
        for (j = 0; j < q.answers.length; j++) if (norm(q.answers[j].text) === given && q.answers[j].fraction > best) best = q.answers[j].fraction;
        return clamp(best / 100, 0, 1) * pts;
      }
      case 'matching': {
        var ok = 0, k;
        if (!response || !q.answers.length) return 0;
        for (k = 0; k < q.answers.length; k++) if (response[k] != null && norm(response[k]) === norm(q.answers[k].matchText || '')) ok++;
        return (ok / q.answers.length) * pts;
      }
    }
    return 0;
  }
  /** Nota total. Las preguntas abiertas se excluyen del máximo (no se pueden corregir sin una persona). */
  function scoreQuiz(quiz, responses) {
    var raw = 0, max = 0, perQuestion = [], i, s;
    for (i = 0; i < quiz.questions.length; i++) {
      s = scoreQuestion(quiz.questions[i], responses[i]);
      perQuestion.push(s);
      if (s !== null) { raw += s; max += quiz.questions[i].points; }
    }
    var percent = max > 0 ? (raw / max) * 100 : 100;
    return { raw: Math.round(raw * 100) / 100, max: max, percent: Math.round(percent * 100) / 100, passed: percent >= quiz.passPercent, perQuestion: perQuestion };
  }
  return { scoreQuestion: scoreQuestion, scoreQuiz: scoreQuiz, norm: norm };
});
