(function (global) {
  'use strict';
  var api = null, started = false, closed = false;
  function find(w) {
    var n = 0;
    while (w && !w.API && w.parent && w.parent !== w && n++ < 500) w = w.parent;
    return (w && w.API) || null;
  }
  api = find(global) || (global.opener ? find(global.opener) : null);
  function get(k) { return api ? String(api.LMSGetValue(k)) : ''; }
  function set(k, v) { return api ? String(api.LMSSetValue(k, String(v))) === 'true' : false; }
  var Scorm = {
    available: function () { return !!api; },
    init: function () {
      if (!api || started) return started;
      started = String(api.LMSInitialize('')) === 'true';
      if (started) {
        var s = get('cmi.core.lesson_status');
        if (s === '' || s === 'not attempted') { set('cmi.core.lesson_status', 'incomplete'); api.LMSCommit(''); }
      }
      return started;
    },
    isDone: function () { var s = get('cmi.core.lesson_status'); return s === 'completed' || s === 'passed'; },
    complete: function () { if (!started || this.isDone()) return; set('cmi.core.lesson_status', 'completed'); api.LMSCommit(''); },
    score: function (raw, max, passed) {
      if (!started) return;
      set('cmi.core.score.min', 0); set('cmi.core.score.max', max); set('cmi.core.score.raw', raw);
      set('cmi.core.lesson_status', passed ? 'passed' : 'failed'); api.LMSCommit('');
    },
    finish: function () { if (started && !closed) { closed = true; api.LMSCommit(''); api.LMSFinish(''); } }
  };
  global.GCMScorm = Scorm;
  global.addEventListener('load', function () { Scorm.init(); });
  global.addEventListener('beforeunload', function () { Scorm.finish(); });
  global.addEventListener('unload', function () { Scorm.finish(); });
})(window);
